/**
 * Handles all incoming requests for /api/book-submissions endpoint
 * DB table: book_submissions
 * Model used: booksubmission.model.js
 * SUPPORTED API ENDPOINTS
 *              GET     /api/book-submissions
 *              GET     /api/book-submissions/:id
 *              GET     /api/book-submissions/issue/:issueId
 *              GET     /api/book-submissions/date-range
 *              POST    /api/book-submissions
 *              DELETE  /api/book-submissions/:id
 *
 *@author     Muskan Khan
@date   DEC,   2025
 * @copyright   www.ibirdsservices.com
 */

const { fetchUser, checkPermission } = require("../middleware/fetchuser.js");
const BookSubmission = require("../models/booksubmission.model.js");
const Notification = require("../models/notification.model.js");

module.exports = (app) => {
  const { body, validationResult, query } = require("express-validator");

  var router = require("express").Router();


  router.get(
    "/",
    fetchUser,
    checkPermission("Book Submissions", "allow_view"),
    async (req, res) => {
      try {
        BookSubmission.init(req.userinfo.tenantcode, req.branchId);

        const filters = {
          ...req.query,
          memberType: req.userinfo.library_member_type
        };

        const submissions = await BookSubmission.findAll(filters);

        return res.status(200).json({
          success: true,
          data: submissions
        });

      } catch (error) {
        console.error("Error fetching book submissions:", error);
        return res.status(500).json({ errors: "Internal server error" });
      }
    }
  );


  router.get("/due_notifications", fetchUser, checkPermission("Book Submissions", "allow_view"), async (req, res) => {

    try {
      const notifications = await BookSubmission.checkbeforeDue();

      return res.status(200).json({
        success: true,
        notifications,
      });

    } catch (error) {
      console.error("❌ Error fetching notifications:", error);

      return res.status(500).json({
        success: false,
        message: "Failed to fetch notifications",
        error: error.message
      });
    }
  });



  router.get("/:id", fetchUser, checkPermission("Book Submissions", "allow_view"), async (req, res) => {
    try {
      BookSubmission.init(req.userinfo.tenantcode, req.branchId);

      const submission = await BookSubmission.findById(
        req.params.id,
        req.userinfo.library_member_type
      );
      if (!submission) {
        return res.status(404).json({ errors: "Book submission not found" });
      }
      return res.status(200).json({ success: true, data: submission });
    } catch (error) {
      console.error("Error fetching book submission:", error);
      return res.status(500).json({ errors: "Internal server error" });
    }
  });

  router.get(
    "/date-range",
    fetchUser,
    checkPermission("Book Submissions", "allow_view"),
    [
      query("startDate").isISO8601().withMessage("Start date must be a valid date"),
      query("endDate").isISO8601().withMessage("End date must be a valid date"),
    ],
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }

        BookSubmission.init(req.userinfo.tenantcode, req.branchId);
        const submissions = await BookSubmission.findByDateRange(req.query.startDate, req.query.endDate);
        return res.status(200).json({ success: true, data: submissions });
      } catch (error) {
        console.error("Error fetching submissions by date range:", error);
        return res.status(500).json({ errors: "Internal server error" });
      }
    }
  );
  router.post(
    "/",
    fetchUser,
    checkPermission("Book Submissions", "allow_create"),
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }

        const userId = req.userinfo?.id || req.userinfo?.id || null;
        if (!userId) {
          return res.status(400).json({ errors: "Librarian ID (submitted_by) is required" });
        }

        BookSubmission.init(req.userinfo.tenantcode, req.branchId);

        const submission = await BookSubmission.create(req.body, userId);

        if (submission && submission.issued_to) {
          try {
            Notification.init(req.userinfo.tenantcode);

            // Notification for the member
            const memberNotification = await Notification.create({
              user_id: submission.issued_to,
              title: "Book Submitted",
              message: `Your book "${submission.book_title}" has been submitted successfully. Condition: ${submission.condition_after}.${submission.penalty > 0 ? ` Penalty: ₹${submission.penalty}` : ' No fine.'}`,
              type: "book_submitted",
              related_id: submission.id,
              related_type: "book_submission"
            });

            // Notification for the librarian who submitted the book
            const librarianNotification = await Notification.create({
              user_id: req.userinfo.id,
              title: "Book Submission Completed",
              message: `Book "${submission.book_title}" has been submitted by member. Condition: ${submission.condition_after}.${submission.penalty > 0 ? ` Penalty: ₹${submission.penalty}` : ''}`,
              type: "book_submitted_librarian",
              related_id: submission.id,
              related_type: "book_submission"
            });

            if (req.app.get('io')) {
              const io = req.app.get('io');
              io.to(`user_${submission.issued_to}`).emit("new_notification", memberNotification);
              io.to(submission.issued_to).emit("new_notification", memberNotification);
              io.to(`user_${req.userinfo.id}`).emit("new_notification", librarianNotification);
              io.to(req.userinfo.id).emit("new_notification", librarianNotification);
            }
          } catch (notifError) {
            console.error("Error creating notification for book submission:", notifError);
          }
        }

        return res.status(200).json({ success: true, data: submission, message: "Book submitted successfully" });
      } catch (error) {
        console.error("Error creating book submission:", error);
        return res.status(500).json({ errors: error.message });
      }
    }
  );
  router.delete(
    "/:id",
    fetchUser,
    checkPermission("Book Submissions", "allow_delete"),
    async (req, res) => {
      try {
        BookSubmission.init(req.userinfo.tenantcode, req.branchId);
        const result = await BookSubmission.deleteById(req.params.id);

        if (result.success) {
          return res.status(200).json(result);
        } else {
          return res.status(404).json(result);
        }
      } catch (error) {
        console.error("Error deleting book submission:", error);
        return res.status(500).json({ errors: error.message });
      }
    }
  );
  router.get("/:bookId/submit-count", fetchUser, checkPermission("Book Submissions", "allow_view"), async (req, res) => {
    try {
      const bookId = req.params.bookId;


      BookSubmission.init(req.userinfo.tenantcode, req.branchId);

      const submitCount = await BookSubmission.getSubmitCountByBookId(bookId);

      return res.status(200).json({ submit_count: submitCount });

    } catch (error) {
      console.error("Error fetching submit count:", error);
      return res.status(500).json({ errors: "Internal server error" });
    }
  });
  router.put(
    "/cancel/:issueId",
    fetchUser,
    checkPermission("Book Submissions", "allow_edit"),
    [
      body("cancellation_reason").optional().isString().withMessage("Cancellation reason must be a string"),
    ],
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }

        const userId = req.userinfo?.id || req.userinfo?.id || null;
        if (!userId) {
          return res.status(400).json({ errors: "User ID is required" });
        }

        BookSubmission.init(req.userinfo.tenantcode, req.branchId);

        const result = await BookSubmission.cancelIssue(
          req.params.issueId,
          userId,
          req.body.cancellation_reason || "Cancelled by librarian"
        );


        if (result.success) {
          try {
            Notification.init(req.userinfo.tenantcode);


            const issueQuery = `
            SELECT bi.issued_to, b.title 
            FROM ${req.userinfo.tenantcode}.book_issues bi
            LEFT JOIN ${req.userinfo.tenantcode}.books b ON bi.book_id = b.id
            WHERE bi.id = $1
          `;
            const issueResult = await sql.query(issueQuery, [req.params.issueId]);

            if (issueResult.rows.length > 0) {
              const issue = issueResult.rows[0];

              const notification = await Notification.create({
                user_id: issue.issued_to,
                title: "Book Submissions Cancelled",
                message: `Your issue for book "${issue.title}" has been cancelled.`,
                type: "issue_cancelled",
                related_id: req.params.issueId,
                related_type: "book_issue"
              });

              if (req.app.get('io')) {
                const io = req.app.get('io');
                io.to(`user_${issue.issued_to}`).emit("new_notification", notification);
              }
            }
          } catch (notifError) {
            console.error("Error creating cancellation notification:", notifError);

          }
        }

        return res.status(200).json(result);

      } catch (error) {
        console.error("Error cancelling issue:", error);
        return res.status(500).json({
          success: false,
          errors: error.message
        });
      }
    }
  );
  app.use(process.env.BASE_API_URL + "/api/book_submissions", router);
};
